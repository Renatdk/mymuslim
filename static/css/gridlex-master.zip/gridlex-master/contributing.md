## Pull requests

**Contributions are welcome!**

You can edit/modify Gridlex as you want, and are free to propose fixes and contributions you find nice or important for you.

Be sure to modify **less and sass files** AND to **edit documentation** to reflect your changes, before submitting a pull request!

*Please note that while Gridlex is open source, this is still my vry little baby, and by submitting a pull request 
you are authorizing me to edit or modify it in any way shape or form. And of course You will be listed in Github 
as a contributor!*

Thx!
